package app.gourdeplayer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private var lib by mutableStateOf<Library?>(null)
    private var granted by mutableStateOf(false)
    private var openId by mutableStateOf<Long?>(null)
    private var settings by mutableStateOf(false)
    private var bgVer by mutableStateOf(0)
    private var active by mutableStateOf(true)

    private val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            reload()
        }
    }

    private val permName =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val perm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        granted = ok
        if (ok) reload()
    }

    private val pickFile = registerForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? ->
        if (u != null) {
            val i = Intent(this, PlayerActivity::class.java)
            i.action = Intent.ACTION_VIEW
            i.data = u
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        }
    }

    private val pickVid = registerForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? ->
        if (u != null) {
            Toast.makeText(this, "Préparation de la vidéo…", Toast.LENGTH_SHORT).show()
            Thread {
                val ok = Bg.saveVideo(this, u)
                runOnUiThread {
                    if (ok) {
                        Store.setBgMode(this, "myvideo")
                        bgVer++
                    } else {
                        Toast.makeText(this, "Vidéo illisible", Toast.LENGTH_SHORT).show()
                    }
                }
            }.start()
        }
    }

    private val pickBg = registerForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? ->
        if (u != null) {
            Thread {
                val ok = Bg.save(this, u)
                runOnUiThread {
                    if (ok) {
                        Store.setBgMode(this, "image")
                        bgVer++
                    } else {
                        Toast.makeText(this, "Image illisible", Toast.LENGTH_SHORT).show()
                    }
                }
            }.start()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        granted = checkSelfPermission(permName) == PackageManager.PERMISSION_GRANTED
        contentResolver.registerContentObserver(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, obs)
        if (granted) reload() else perm.launch(permName)
        setContent { GpTheme { Root() } }
    }

    override fun onStart() {
        super.onStart()
        active = true
    }

    override fun onStop() {
        super.onStop()
        active = false
    }

    override fun onResume() {
        super.onResume()
        if (granted) reload()
    }

    override fun onDestroy() {
        contentResolver.unregisterContentObserver(obs)
        super.onDestroy()
    }

    private fun reload() {
        if (!granted) return
        Thread {
            val l = Repo.library(this)
            lib = l
        }.start()
    }

    private fun openFolder(f: Folder) {
        Store.setFolderSeen(this, f.id, System.currentTimeMillis() / 1000)
        openId = f.id
        reload()
    }

    private fun play(vs: List<Vid>, index: Int) {
        val i = Intent(this, PlayerActivity::class.java)
        i.putExtra("ids", vs.map { it.id }.toLongArray())
        i.putExtra("names", vs.map { it.name }.toTypedArray())
        i.putExtra("index", index)
        startActivity(i)
    }

    @Composable
    private fun Root() {
        var splash by remember { mutableStateOf(true) }
        LaunchedEffect(Unit) {
            delay(1600)
            splash = false
        }
        val hero by animateFloatAsState(if (splash) 1f else 0f, tween(900), label = "hero")
        val img = remember(bgVer) { Bg.load(this@MainActivity) }
        val dim = remember(bgVer) { Store.bgDim(this@MainActivity) }
        val vmode = remember(bgVer) { Store.bgMode(this@MainActivity) }
        val isVideo = vmode == "video" || vmode == "myvideo"
        val vfit = remember(bgVer) { vmode == "myvideo" && Store.bgFit(this@MainActivity) }
        val vuri = remember(bgVer) {
            val f = Bg.videoFile(this@MainActivity)
            if (vmode == "myvideo" && f.exists()) Uri.fromFile(f) else Uri.parse("asset:///bg/gourde.mp4")
        }
        Box(Modifier.fillMaxSize()) {
            if (isVideo) {
                if (hero > 0.3f) FireGourdBackground(hero)
                if (hero < 0.3f) VideoBackground(active, dim, vuri, vfit, bgVer)
            } else {
                if (img == null || hero > 0.01f) FireGourdBackground(hero)
                if (img != null) PhotoBackground(img, dim, 1f - hero)
            }
            Box(Modifier.fillMaxSize().alpha(1f - hero)) { Content() }
            if (hero > 0.02f) {
                Text(
                    "Gourde Player", color = Pal.Gold, fontSize = 34.sp, fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 110.dp).alpha(hero)
                )
            }
        }
    }

    @Composable
    private fun Content() {
        val l = lib
        val id = openId
        BackHandler(enabled = settings || id != null) {
            if (settings) settings = false else openId = null
        }
        val hist: List<Vid> =
            if (l != null) Store.recent(this).mapNotNull { r -> l.videos.find { it.id == r } } else emptyList()
        val f: Folder? = when {
            l == null || id == null -> null
            id == -2L -> Folder(-2L, "Historique", hist, false)
            else -> l.folder(id)
        }
        val onClear: (() -> Unit)? =
            if (id == -2L) ({
                Store.clearHistory(this)
                openId = null
                reload()
            }) else null
        when {
            settings -> SettingsScreen(bgVer, { settings = false }, { pickBg.launch("image/*") }, { pickVid.launch("video/*") }, { bgVer++ })
            !granted -> Column(
                Modifier.fillMaxSize().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Autorise l'accès aux vidéos pour afficher tes dossiers.",
                    color = Pal.Silver, fontSize = 16.sp
                )
                Box(Modifier.padding(top = 16.dp)) { Pill("Autoriser", { perm.launch(permName) }, Pal.Gold, true) }
            }
            l == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Chargement…", color = Pal.Silver)
            }
            f != null -> FolderScreen(f, l, { openId = null }, { vs, i -> play(vs, i) }, onClear)
            else -> HomeScreen(
                l, { openFolder(it) }, { vs, i -> play(vs, i) },
                { openId = -2L }, { settings = true },
                onOpenFile = { pickFile.launch("video/*") }
            )
        }
    }
}
