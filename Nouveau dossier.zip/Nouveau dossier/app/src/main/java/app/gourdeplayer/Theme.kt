package app.gourdeplayer

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object Pal {
    val Navy = Color(0xFF0A1128)
    val NavyMid = Color(0xFF16224D)
    val Silver = Color(0xFFB8C8E8)
    val Gold = Color(0xFFE6BC62)
    val GoldDark = Color(0xFF9C7425)
    val Red = Color(0xFFD92B2B)
    val Cyan = Color(0xFF4FE3E0)
    val Fire = Color(0xFFFF8A3D)
    val Card = Color(0x99101A3C)
    val goldBrush = Brush.linearGradient(listOf(Gold, GoldDark, Gold))
}

@Composable
fun GpTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = Pal.Gold, background = Pal.Navy, surface = Pal.NavyMid),
        content = content
    )
}
