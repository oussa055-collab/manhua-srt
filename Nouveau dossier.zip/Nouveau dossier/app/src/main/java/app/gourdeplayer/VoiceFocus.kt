package app.gourdeplayer

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/**
 * Réduit la musique de fond en temps réel : garde la zone de la voix (≈200 Hz à 5 kHz),
 * baisse les graves et les aigus (instruments, percussions) et le son « large » du stéréo
 * (la voix est au centre, la musique est souvent répartie sur les côtés).
 */
class VoiceFocus : BaseAudioProcessor() {
    @Volatile
    var level = 0f

    private class Bq {
        var b0 = 1.0
        var b1 = 0.0
        var b2 = 0.0
        var a1 = 0.0
        var a2 = 0.0
        var x1 = 0.0
        var x2 = 0.0
        var y1 = 0.0
        var y2 = 0.0

        fun run(x: Double): Double {
            val y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            x2 = x1
            x1 = x
            y2 = y1
            y1 = y
            return y
        }
    }

    private var ch = 2
    private var filt: Array<Array<Bq>> = emptyArray()
    private var raw = DoubleArray(2)
    private var tmp = DoubleArray(2)

    private fun high(f: Bq, fc: Double, sr: Double) {
        val w = 2.0 * PI * fc / sr
        val cw = cos(w)
        val al = sin(w) / (2.0 * 0.7071)
        val a0 = 1.0 + al
        f.b0 = (1.0 + cw) / 2.0 / a0
        f.b1 = -(1.0 + cw) / a0
        f.b2 = f.b0
        f.a1 = -2.0 * cw / a0
        f.a2 = (1.0 - al) / a0
    }

    private fun low(f: Bq, fc: Double, sr: Double) {
        val w = 2.0 * PI * fc / sr
        val cw = cos(w)
        val al = sin(w) / (2.0 * 0.7071)
        val a0 = 1.0 + al
        f.b0 = (1.0 - cw) / 2.0 / a0
        f.b1 = (1.0 - cw) / a0
        f.b2 = f.b0
        f.a1 = -2.0 * cw / a0
        f.a2 = (1.0 - al) / a0
    }

    private fun peak(f: Bq, fc: Double, gainDb: Double, q: Double, sr: Double) {
        val a = 10.0.pow(gainDb / 40.0)
        val w = 2.0 * PI * fc / sr
        val cw = cos(w)
        val al = sin(w) / (2.0 * q)
        val a0 = 1.0 + al / a
        f.b0 = (1.0 + al * a) / a0
        f.b1 = -2.0 * cw / a0
        f.b2 = (1.0 - al * a) / a0
        f.a1 = -2.0 * cw / a0
        f.a2 = (1.0 - al / a) / a0
    }

    private fun setup(sr: Double) {
        filt = Array(ch) {
            val a = Bq()
            val b = Bq()
            val c = Bq()
            val d = Bq()
            high(a, 200.0, sr)
            high(b, 200.0, sr)
            low(c, 5500.0, sr)
            peak(d, 2000.0, 4.0, 0.8, sr)
            arrayOf(a, b, c, d)
        }
        raw = DoubleArray(ch)
        tmp = DoubleArray(ch)
    }

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT || inputAudioFormat.channelCount < 1) {
            return AudioProcessor.AudioFormat.NOT_SET
        }
        ch = inputAudioFormat.channelCount
        setup(inputAudioFormat.sampleRate.toDouble())
        return inputAudioFormat
    }

    override fun onFlush() {
        for (row in filt) for (f in row) {
            f.x1 = 0.0
            f.x2 = 0.0
            f.y1 = 0.0
            f.y2 = 0.0
        }
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val n = inputBuffer.remaining()
        if (n == 0) return
        val out = replaceOutputBuffer(n)
        val lv = level.toDouble()
        if (lv < 0.01 || filt.isEmpty()) {
            out.put(inputBuffer)
            out.flip()
            return
        }
        inputBuffer.order(ByteOrder.nativeOrder())
        val side = 1.0 - 0.75 * lv
        val gain = 1.0 + 0.35 * lv
        val frames = n / (2 * ch)
        for (i in 0 until frames) {
            for (c in 0 until ch) {
                val v = inputBuffer.short.toDouble() / 32768.0
                raw[c] = v
                tmp[c] = v
            }
            if (ch == 2) {
                val m = (raw[0] + raw[1]) / 2.0
                val s = (raw[0] - raw[1]) / 2.0 * side
                tmp[0] = m + s
                tmp[1] = m - s
            }
            for (c in 0 until ch) {
                var v = tmp[c]
                for (f in filt[c]) v = f.run(v)
                val mix = raw[c] * (1.0 - lv) + v * gain * lv
                out.putShort((mix * 32767.0).coerceIn(-32768.0, 32767.0).toInt().toShort())
            }
        }
        while (inputBuffer.hasRemaining()) out.put(inputBuffer.get())
        out.flip()
    }
}
