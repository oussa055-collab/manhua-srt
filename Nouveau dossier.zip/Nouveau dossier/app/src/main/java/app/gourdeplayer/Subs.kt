package app.gourdeplayer

class Cue(val start: Long, val end: Long, val text: String)

object Subs {
    fun decode(bytes: ByteArray): String {
        var s = String(bytes, Charsets.UTF_8)
        if (s.contains('\uFFFD')) {
            s = try {
                String(bytes, charset("windows-1256"))
            } catch (e: Exception) {
                s
            }
        }
        return s.removePrefix("\uFEFF")
    }

    private fun t(s: String): Long {
        var sec = 0.0
        for (p in s.trim().replace(',', '.').split(':')) sec = sec * 60 + (p.trim().toDoubleOrNull() ?: 0.0)
        return (sec * 1000).toLong()
    }

    private val tag = Regex("<[^>]*>|\\{[^}]*\\}")

    fun parse(text: String): List<Cue> {
        val out = ArrayList<Cue>()
        if (text.contains("[Script Info]") || text.contains("Dialogue:")) {
            var startIdx = 1
            var endIdx = 2
            var textIdx = 9
            for (line in text.lines()) {
                val l = line.trim()
                if (l.startsWith("Format:")) {
                    val cols = l.removePrefix("Format:").split(',').map { it.trim() }
                    if (cols.contains("Start") && cols.contains("Text")) {
                        startIdx = cols.indexOf("Start")
                        endIdx = cols.indexOf("End")
                        textIdx = cols.indexOf("Text")
                    }
                } else if (l.startsWith("Dialogue:")) {
                    val f = l.removePrefix("Dialogue:").split(',', limit = textIdx + 1)
                    if (f.size > textIdx) {
                        val tx = f[textIdx].replace("\\N", "\n").replace("\\n", "\n").replace(tag, "").trim()
                        if (tx.isNotEmpty()) out.add(Cue(t(f[startIdx]), t(f[endIdx]), tx))
                    }
                }
            }
        } else {
            val blocks = text.replace("\r", "").split(Regex("\n\\s*\n"))
            for (b in blocks) {
                val lines = b.trim().split("\n")
                val i = lines.indexOfFirst { it.contains("-->") }
                if (i < 0) continue
                val times = lines[i].split("-->")
                if (times.size < 2) continue
                val st = t(times[0])
                val en = t(times[1].trim().split(" ")[0])
                val tx = lines.drop(i + 1).joinToString("\n").replace(tag, "").trim()
                if (tx.isNotEmpty()) out.add(Cue(st, en, tx))
            }
        }
        out.sortBy { it.start }
        return out
    }
}
